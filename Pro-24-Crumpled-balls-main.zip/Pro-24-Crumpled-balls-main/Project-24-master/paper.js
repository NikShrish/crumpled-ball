class paper
{

Constructor (x,y,r)
{
    var options ={
        isStatic:true 
         restitution :0.3,
        fricition:0.5,
        denisity:1.2,

            }
    this.x=x;
    this.y=y;
    this.r=r;
this.body = Bodies.circle(this.x,this.y,this.r/2,options)
World.addd(world,this.body);

}
display()
{
var paperpos = this.body.position;

Push()
translate(paperpos.x,paperpos.y);
rectMode(CENTER)
strokeWeight(3);
Fill(255,0,255)
ellipse(0,0,this.r,this.r);
Pop()
}

}